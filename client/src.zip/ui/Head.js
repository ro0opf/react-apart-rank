import React, { useState } from 'react';
import './Head.css';
import AutoCompleteText from '../AutoCompleteText';
import res from '../res.json'

function Head() {
    const mainIconimageSrc = require("../image/ic_apartments.png");
    const [autoText, setAutoText] = useState({
        suggestions: [],
        text: ''
    });

    function suggestionSelected(value) {
        setAutoText({
            suggestions: [],
            text: value[0]
        });
    }

    function renderSuggestions() {
        const suggestions = autoText.suggestions;
        if (suggestions.length === 0) {
            return null;
        }

        return (
            <div className="HeadAutoCompleteItem">
                <ul className="Items">
                    {suggestions.map((item) =>
                        <li onClick={() => suggestionSelected(item)}>
                            {item[0]}
                            <small>
                                <span>
                                    {item[1][0].address}
                                </span>
                            </small>
                        </li>
                    )}
                </ul>
            </div>
        );
    }

    return (
        <>
            <div className="Head">
                <h1>
                    APART.GG
                </h1>

                <img className="MainIcon" src={mainIconimageSrc} alt="apart.gg"></img>
                <AutoCompleteText items={res} autoText={autoText} setAutoText={setAutoText} />
            </div>
            {renderSuggestions()}
        </>
    )
}

export default Head;