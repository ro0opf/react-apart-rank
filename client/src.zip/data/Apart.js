import React, { useState } from 'react';
import axios from 'axios';
import { useAsync } from '../util/useAsync';

async function getAparts(keyword) {
    const response = await axios.get('http://116.123.85.116:9999/apart', {
        params: {
            apart_name: keyword
        }
    });
    return response.data;
}

function Aparts() {
    const [state, refetch] = useAsync(getAparts("자이"), [], true);
    const { loading, data: aparts, error } = state;

    if (loading) return <div>로딩중...</div>;
    if (error) return <div>에러!!!</div>;
    if (!aparts) return null;

    return (
        <div className="HeadAutoCompleteItem">
            <ul className="Items">
                {aparts.map((apart) =>
                    <li onClick={() => suggestionSelected(apart)}>
                        {apart[0]}
                        <small>
                            <span>
                                {apart[1][0].address}
                            </span>
                        </small>
                    </li>
                )}
            </ul>
        </div>
    )
}

export default Users;