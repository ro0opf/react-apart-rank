import React from 'react';
import MenuIconUrl, { ReactComponent as MenuIcon } from './image/icon/btn_menu.svg';

export default function App() {
  return (
    <div>
      React + TypeScript + Webpack!adwawd
      <div>
        <img src={MenuIconUrl} alt="Bulb Icon" />
      </div>
      <MenuIcon />
    </div>
  );
}
