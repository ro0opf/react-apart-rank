import React, { useState, useRef } from 'react';
import './AutoCompleteText.css';

function AutoCompleteText(props) {
    function onTextChanged(e) {
        const keys = Object.keys(props.items);
        const value = e.target.value;
    
        let suggestions = [];
        if (value.length > 0) {
            const regex = new RegExp(`${value}`, 'i');
            keys.forEach(function (element, index, array) {
                var match = regex.exec(element);

                if (match != null) {
                    suggestions.push([element, props.items[element]]);
                }
            });
        }

        props.setAutoText({
            suggestions: suggestions,
            text: value
        });
    }

    const scrollToAutoCompleteText = (ref) => window.scrollTo(0, ref.current.offsetTop)
    const myRef = useRef(null);
    const executeScroll = () => scrollToAutoCompleteText(myRef);

    return (
        <div ref={myRef} className="AutoCompleteText">
            <input onClick={executeScroll} value={props.autoText.text} onChange={onTextChanged} type="text" />
        </div>
    )
}

export default AutoCompleteText;